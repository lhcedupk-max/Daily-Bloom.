# Daily Bloom

A local-first React + TypeScript PWA with an Android wrapper powered by Capacitor.

## Run locally
1. Install Node.js 20+.
2. Run `npm install`.
3. Run `npm run dev` and open the displayed local URL.
4. Run `npm run build` for a production PWA build.

## Install as a PWA
Deploy the `dist/` folder to an HTTPS host, open the site in Chrome on Android, then use **Install app** / **Add to Home screen**. The service worker caches the app shell for offline use after the first successful load.

## Build an Android APK
1. Install Android Studio and its Android SDK.
2. Run `npm install`.
3. Run `npm run android:add` once to generate the Android project.
4. Run `npm run android:sync`.
5. Run `npm run android:open`, then in Android Studio choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The generated debug APK is for personal testing. A release APK should be signed in Android Studio before distribution.

## Data
Habits, daily status records, goals, journal entries and settings are stored in IndexedDB on the device. Use Settings → Export backup regularly. Browser/PWA data can be cleared by Android or the user; exported backups are the recovery path.

## Current implementation scope
This is the first functional foundation. It includes local persistence, responsive navigation, habit status tracking, weekly/monthly goal creation and manual progress, journal entries, date selection, reports overview, backup export/restore, language toggle, dark mode and PWA setup. Advanced specification items such as full notification scheduling, review workflow, goal milestones/templates/automatic habit-goal contribution, PIN lock, PDF/CSV reports, streak analytics and complete Urdu localization remain to be implemented and tested in subsequent phases.
