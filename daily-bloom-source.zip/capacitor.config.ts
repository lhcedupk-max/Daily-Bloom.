import type { CapacitorConfig } from '@capacitor/cli'
const config: CapacitorConfig = { appId:'com.dailybloom.app', appName:'Daily Bloom', webDir:'dist', bundledWebRuntime:false }
export default config