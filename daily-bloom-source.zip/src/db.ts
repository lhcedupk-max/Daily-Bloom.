import Dexie, { type Table } from 'dexie'
export type SectionName='Educational'|'Emotional'|'Technical'|'Spiritual'|'Healthy'
export type Habit={id:string;name:string;description:string;section:SectionName;category:string;priority:'High'|'Medium'|'Low';target:number;weekdays:number[];active:boolean;createdAt:string}
export type HabitRecord={id:string;habitId:string;date:string;status:'Completed'|'Pending'|'Skipped';quantity:number}
export type Goal={id:string;name:string;description:string;period:'Weekly'|'Monthly';section:SectionName;target:number;progress:number;deadline:string;priority:'High'|'Medium'|'Low';notes:string;status:'Active'|'Completed'|'Archived';createdAt:string}
export type JournalEntry={id:string;date:string;title:string;body:string;createdAt:string}
export type Review={id:string;date:string;achievements:string;difficulties:string;reflection:string}
class BloomDB extends Dexie {
 habits!:Table<Habit,string>; records!:Table<HabitRecord,string>; goals!:Table<Goal,string>; journal!:Table<JournalEntry,string>; reviews!:Table<Review,string>; settings!:Table<{key:string;value:any},string>
 constructor(){super('DailyBloomDB');this.version(1).stores({habits:'id,section,category,active,name',records:'id,habitId,date,[habitId+date]',goals:'id,period,section,deadline,status',journal:'id,date,title',reviews:'id,date',settings:'key'})}
}
export const db=new BloomDB()
export const uid=()=>crypto.randomUUID()
export const today=()=>new Date().toISOString().slice(0,10)
export const sections:SectionName[]=['Educational','Emotional','Technical','Spiritual','Healthy']
export async function ensureTodayRecords(){const date=today(), habits=await db.habits.filter(h=>h.active&&h.weekdays.includes(new Date().getDay())).toArray();await db.transaction('rw',db.records,async()=>{for(const h of habits){const found=await db.records.where({habitId:h.id,date}).first();if(!found)await db.records.add({id:uid(),habitId:h.id,date,status:'Pending',quantity:0})}})}
