import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'
export default defineConfig({ plugins:[react(),VitePWA({registerType:'autoUpdate',includeAssets:['flower.svg'],manifest:{name:'Daily Bloom',short_name:'Daily Bloom',description:'Personal growth and habit tracker',theme_color:'#087f5b',background_color:'#f6fbf8',display:'standalone',start_url:'/',icons:[{src:'/flower.svg',sizes:'any',type:'image/svg+xml',purpose:'any maskable'}]},workbox:{globPatterns:['**/*.{js,css,html,svg,png,woff2}']}})] })